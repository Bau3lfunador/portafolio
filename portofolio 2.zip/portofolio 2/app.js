const express = require('express');
const app = express();
const methodOverride = require('method-override');
const adminRoutes =
require('./src/routes/adminRoutes.js');
const authRoutes = require('./src/routes/authRoutes.js');
const mainRoutes = require('./src/routes/mainRoutes.js');
const shopRoutes = require('./src/routes/PortfolioRoutes.js');
const PORT = 3000;
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'))
app.use(express.static('public'));
app.use('/', mainRoutes);
app.use('/portfolio', PortfolioRoutes);
app.use('/admin', adminRoutes);
app.use('/auth', authRoutes);
app.listen(PORT, () => console.log(`Servidor corriendo en http://localhost:${PORT}`));