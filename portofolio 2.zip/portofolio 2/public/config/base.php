<?php
$conexion = new mysqli("localhost", "root", "", "portfolio");
if ($conexion->connect_errno) {
    die("Error de conexión: " . $conexion->connect_error);
}
if (isset($_POST['registro'])) {
    $usuario = $_POST['usuario'];
    $correo = $_POST['correo'];
    $password = $_POST['password'];

    $sql = "INSERT INTO usuarios (usuario, correo, password) VALUES ('$usuario', '$correo', '$password')";

    if ($conexion->query($sql)) {
        echo "Registro exitoso";
    } else {
        echo "Error: " . $conexion->error;
    }
}
if (isset($_POST['login'])) {
    $correo = $_POST['correo'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM usuarios WHERE correo = '$correo' AND password = '$password'";
    $resultado = $conexion->query($sql);

    if ($resultado->num_rows > 0) {
        echo "Bienvenido!";
    } else {
        echo "Correo o contraseña incorrectos";
    }
}
$conexion->close();
?>
