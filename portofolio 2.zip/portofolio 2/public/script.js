document.getElementById("formulario").addEventListener("submit", function(e) {
  e.preventDefault();

  const nombre = document.getElementById("nombre").value;
  const imagen = document.getElementById("imagen").value;
  const fecha = document.getElementById("fecha").value;
  const descripcion = document.getElementById("descripcion").value;
  const etiqueta = document.getElementById("etiqueta").value;

  const contenedor = document.getElementById("recientes");

  const div = document.createElement("div");
  div.innerHTML = `
    <img src="${imagen}" alt="${nombre}">
    <p><b>${nombre}</b></p>
    <p>${descripcion}</p>
    <small>${fecha} - ${etiqueta}</small>
  `;

  contenedor.appendChild(div);

  e.target.reset();
});
