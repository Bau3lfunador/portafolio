const { conn } = require('../config/conn');
const getAll = async () => {
  try {
    const [rows] = await conn.query('SELECT * FROM product;');
    return rows;
  } catch (error) {
    return {
      error: true,
      message: 'Hemos detectado un error: ' + error
    };
  }
};
const getOne = async (id) => {
  try {
    const [rows] = await conn.query(
      'SELECT * FROM product WHERE product_id = ?;',
      [id]
    );
    return rows;
  } catch (error) {
    return {
      error: true,
      message: 'Hemos detectado un error: ' + error
    };
  }
};
const create = async (params) => {
  try {
    const sql =
      'INSERT INTO product (product_name, product_description, price, stock, discount, sku, img_product, category_id) VALUES (?,?,?,?,?,?,?,?)';
    const [result] = await conn.query(sql, params);
    return result;
  } catch (error) {
    return {
      error: true,
      message: 'Hemos detectado un error: ' + error
    };
  }
};
const edit = async (params, id) => {
  try {
    const [result] = await conn.query(
      'UPDATE product SET ? WHERE product_id = ?;',
      [params, id]
    );
    return result;
  } catch (error) {
    return {
      error: true,
      message: 'Hemos detectado un error: ' + error
    };
  }
};
const deleteOne = async (id) => {
  try {
    const [result] = await conn.query(
      'DELETE FROM product WHERE product_id = ?;',
      [id]
    );
    return result;
  } catch (error) {
    return {
      error: true,
      message: 'Hemos detectado un error: ' + error
    };
  }
};
module.exports = {
  getAll,
  getOne,
  create,
  edit,
  deleteOne
};