const db = require('config/base.php');
module.exports = {
    createUser: (data, callback) => {
        const sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        db.query(sql, [data.name, data.email, data.password], callback);
    },
    getUserByEmail: (email, callback) => {
        const sql = "SELECT * FROM users WHERE email = ?";
        db.query(sql, [email], callback);
    }
};
const db = require("config/base.php");
const UserModel = {
    buscarPorEmail: (email) => {
        return new Promise((resolve, reject) => {
            db.query(
                "SELECT * FROM users WHERE email = ?",
                [email],
                (err, results) => {
                    if (err) return reject(err);
                    resolve(results[0]);
                }
            );
        });
    },
    crear: (nombre, email, password) => {
        return new Promise((resolve, reject) => {
            db.query(
                "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
                [nombre, email, password],
                (err, result) => {
                    if (err) return reject(err);
                    resolve(result.insertId);
                }
            );
        });
    },
    buscarPorId: (id) => {
        return new Promise((resolve, reject) => {
            db.query(
                "SELECT * FROM users WHERE id = ?",
                [id],
                (err, results) => {
                    if (err) return reject(err);
                    resolve(results[0]);
                }
            );
        });
    }
};
module.exports = UserModel;