module.exports = {
    index: (req, res) => {
        Project.getAllProjects((projects) => {
            res.render('portfolio', { projects });
        });
    },
    detail: (req, res) => {
        Project.getProjectById(req.params.id, (project) => {
            res.render('projectDetail', { project });
        });
    }
};
const ProyectoModel = require("proyectoModel");
const portfolioController = {
    listar: async (req, res) => {
        const proyectos = await ProyectoModel.obtenerTodos();
        res.render("portfolio", { proyectos });
    }
};
module.exports = portfolioController;