module.exports = {
home: (req, res) => res.send("Página de Home"),
contact: (req, res) => res.send("Página de Contacto"),
about: (req, res) => res.send("Página Sobre Nosotros")
}
module.exports = {
home: (req, res) =>
res.render('index', {
title: 'Inicio'
}),
contact: (req, res) =>
res.render('contact', {
title: 'Contacto'
}),
about: (req, res) => res.render('about', {
title: 'Sobre nosotros'
})
}