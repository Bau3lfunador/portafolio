module.exports = {
login: (req, res) => res.render('auth/login'),
doLogin: (req, res) => res.send("ruta que válida datos del login"),
register: (req, res) => res.render('auth/register'),
doRegister: (req, res) => res.send("ruta que crea nuevo usuario"), 
logout: (req, res) => res.send("ruta que cierra sesión"),
}
const authController = {

    mostrarLogin: (req, res) => {
        res.render("auth/login");
    },
    procesarLogin: async (req, res) => {
        const { email, password } = req.body;

        const usuario = await UserModel.buscarPorEmail(email);

        if (!usuario) return res.send("Usuario no encontrado");
        if (usuario.password !== password) return res.send("Clave incorrecta");

        res.send("Login correcto");
    },
    mostrarRegister: (req, res) => {
        res.render("auth/register");
    },
    procesarRegister: async (req, res) => {
        const { name, email, password } = req.body;
        await UserModel.crear(name, email, password);
        res.send("Usuario registrado");
    }
};
module.exports = authController;
