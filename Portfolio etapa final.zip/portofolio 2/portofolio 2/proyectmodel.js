const db = require('../config/db');
module.exports = {
    getAllProjects: (callback) => {
        db.query("SELECT * FROM projects", (err, results) => {
            if (err) throw err;
            callback(results);
        });
    },
    getProjectById: (id, callback) => {
        db.query("SELECT * FROM projects WHERE id = ?", [id], (err, results) => {
            if (err) throw err;
            callback(results[0]);
        });
    }
};
