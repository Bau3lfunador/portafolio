<?php
require_once __DIR__ . "config/base.php";
require_once "proyecto.php";
class ProyectoModel {
    public static function obtenerTodos() {
        global $conexion;
        $sql = "SELECT * FROM proyectos";
        $result = $conexion->query($sql);
        $proyectos = [];
        while ($row = $result->fetch_assoc()) {
            $proyectos[] = new Proyecto(
                $row['id'],
                $row['titulo'],
                $row['descripcion'],
                $row['url'],
                $row['imagen']
            );
        }
        return $proyectos;
    }
    public static function obtenerPorId($id) {
        global $conexion;
        $sql = $conexion->prepare("SELECT * FROM proyectos WHERE id = ?");
        $sql->bind_param("i", $id);
        $sql->execute();
        $resultado = $sql->get_result();
        if ($row = $resultado->fetch_assoc()) {
            return new Proyecto(
                $row['id'],
                $row['titulo'],
                $row['descripcion'],
                $row['url'],
                $row['imagen']
            );
        }
        return null;
    }
    public static function crear($titulo, $descripcion, $url, $imagen) {
        global $conexion;
        $sql = $conexion->prepare("INSERT INTO proyectos (titulo, descripcion, url, imagen) VALUES (?, ?, ?, ?)");
        $sql->bind_param("ssss", $titulo, $descripcion, $url, $imagen);
        return $sql->execute();
    }
    public static function actualizar($id, $titulo, $descripcion, $url, $imagen) {
        global $conexion;
        $sql = $conexion->prepare("UPDATE proyectos SET titulo = ?, descripcion = ?, url = ?, imagen = ? WHERE id = ?");
        $sql->bind_param("ssssi", $titulo, $descripcion, $url, $imagen, $id);
        return $sql->execute();
    }
    public static function eliminar($id) {
        global $conexion;
        $sql = $conexion->prepare("DELETE FROM proyectos WHERE id = ?");
        $sql->bind_param("i", $id);
        return $sql->execute();
    }
}
?>