<?php
class Proyecto {
    public $id;
    public $titulo;
    public $descripcion;
    public $url;
    public $imagen;
    public function __construct($id, $titulo, $descripcion, $url, $imagen) {
        $this->id = $id;
        $this->titulo = $titulo;
        $this->descripcion = $descripcion;
        $this->url = $url;
        $this->imagen = $imagen;
    }
}
?>
