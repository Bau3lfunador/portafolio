require('dotenv').config();
const path = require('path');
const express = require('express');
const app = express();
app.use(express.static(path.join(__dirname, 'public')));
const methodOverride = require('method-override');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname ,'./src/views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'))
app.use(express.static('public'));

const adminRoutes = require('./src/routes/adminRoutes.js');
const authRoutes = require('./src/routes/authRoutes.js');
const mainRoutes = require('./src/routes/mainRoutes.js');
const portafolioRoutes = require('./src/routes/portafolioRoutes.js');

const PORT = process.env.PORT || 3000;


app.use('/', mainRoutes);
app.use('/portafolio', portafolioRoutes);
app.use('/admin', adminRoutes);
app.use('/auth', authRoutes);

app.use((req, res) => {
  res.status(404).send('Recurso no encontrado');
});

app.listen(PORT, () => console.log(`Servidor corriendo en http://localhost:${PORT}`));