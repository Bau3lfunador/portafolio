const db = require('../database/config');

const proyectosModel = {

  obtenerRecientes: (callback) => {
    const sql = "SELECT * FROM proyectos ORDER BY id DESC LIMIT 2";
    db.query(sql, callback);
  },

  obtenerTodos: (filtro, values, callback) => {
    const sql = `SELECT * FROM proyectos ${filtro}`;
    db.query(sql, values, callback);
  },

  obtenerPorId: (id, callback) => {
    const sql = "SELECT * FROM proyectos WHERE id = ?";
    db.query(sql, [id], callback);
  },

  crear: (data, callback) => {
    const sql = `
      INSERT INTO proyectos (nombre, descripcion, portada, tecnologias)
      VALUES (?, ?, ?, ?)
    `;
    db.query(sql, data, callback);
  },

  actualizar: (data, id, callback) => {
    const sql = `
      UPDATE proyectos
      SET nombre=?, descripcion=?, portada=?, tecnologias=?
      WHERE id=?
    `;
    db.query(sql, [...data, id], callback);
  },

  eliminar: (id, callback) => {
    const sql = "DELETE FROM proyectos WHERE id=?";
    db.query(sql, [id], callback);
  }

};

module.exports = proyectosModel;