const proyectosModel = require('../models/proyectosModel');

module.exports = {
  home: (req, res) => {
    proyectosModel.obtenerRecientes((err, results) => {
      if (err) return res.send(err);
      res.render('index', { title: "Inicio", projects: results });
    });
  },

  contact: (req, res) => {
    res.render('contact', { title: "Contacto" });
  },

  about: (req, res) => {
    res.render('about', { title: "Sobre Nosotros" });
  }
};