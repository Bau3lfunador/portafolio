const proyectosModel = require('../models/proyectosModel');

module.exports = {

  portfolio: (req, res) => {
    let filtro = "";
    let values = [];

    if (req.query.tech) {
      filtro = "WHERE tecnologias LIKE ?";
      values = [`%${req.query.tech}%`];
    }

    proyectosModel.obtenerTodos(filtro, values, (err, results) => {
      if (err) return res.send(err);
      res.render('portafolio/index', { title: "Proyectos", projects: results });
    });
  },

  item: (req, res) => {
    const id = req.params.id;

    proyectosModel.obtenerPorId(id, (err, results) => {
      if (err) return res.send(err);
      if (results.length === 0) return res.send("Proyecto no encontrado");

      res.render('portafolio/item', {
        title: results[0].nombre,
        project: results[0]
      });
    });
  }
};