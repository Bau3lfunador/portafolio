module.exports = {
  login: (req, res) => {
    res.render('auth/login', { title: 'Iniciar sesión' });
  },

  doLogin: (req, res) => {
    res.send('Procesando inicio de sesión (a implementar en Etapa 4)');
  },

  register: (req, res) => {
    res.render('auth/register', { title: 'Registrarse' });
  },

  doRegister: (req, res) => {
    res.send('Procesando registro (a implementar en Etapa 4)');
  },

  logout: (req, res) => {
    res.send('Cierre de sesión (a implementar en Etapa 4)');
  }
};