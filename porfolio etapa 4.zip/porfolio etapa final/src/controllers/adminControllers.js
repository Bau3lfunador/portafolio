const proyectosModel = require('../models/proyectosModel');

module.exports = {

  index: (req, res) => {
    proyectosModel.obtenerTodos("", [], (err, results) => {
      if (err) return res.send(err);
      res.render('admin/index', { title: "Panel Admin", projects: results });
    });
  },

  createForm: (req, res) => {
    res.render('admin/create', { title: "Crear Proyecto" });
  },

  create: (req, res) => {
    const data = [
      req.body.nombre,
      req.body.descripcion,
      req.body.portada,
      req.body.tecnologias
    ];

    proyectosModel.crear(data, (err) => {
      if (err) return res.send(err);
      res.redirect('/admin');
    });
  },

  editForm: (req, res) => {
    proyectosModel.obtenerPorId(req.params.id, (err, results) => {
      if (err) return res.send(err);
      if (results.length === 0) return res.send("Proyecto inexistente");

      res.render('admin/edit', {
        title: "Editar Proyecto",
        project: results[0]
      });
    });
  },

  update: (req, res) => {
    const data = [
      req.body.nombre,
      req.body.descripcion,
      req.body.portada,
      req.body.tecnologias
    ];

    proyectosModel.actualizar(data, req.params.id, (err) => {
      if (err) return res.send(err);
      res.redirect('/admin');
    });
  },

  remove: (req, res) => {
    proyectosModel.eliminar(req.params.id, (err) => {
      if (err) return res.send(err);
      res.redirect('/admin');
    });
  }
};