const express = require('express');
const router = express.Router();
const portafolioControllers = require('../controllers/portafolioControllers');

router.get('/', portafolioControllers.portfolio);
router.get('/item/:id', portafolioControllers.item)

module.exports = router;