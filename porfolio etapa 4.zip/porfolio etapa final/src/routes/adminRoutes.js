const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminControllers');

router.get('/', adminController.index);

router.get('/create', adminController.createForm);
router.post('/create', adminController.create);

router.get('/edit/:id', adminController.editForm);
router.put('/edit/:id', adminController.update);

router.delete('/delete/:id', adminController.remove);

module.exports = router;