const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'portafolio'
});

db.connect(err => {
    if (err) {
        console.log(' Error al conectar con MySQL:', err);
        return;
    }
    console.log('Conectado a MySQL correctamente');
});

module.exports = db;