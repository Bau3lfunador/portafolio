-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-11-2025 a las 22:03:19
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `portafolio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

CREATE TABLE `proyectos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `portada` varchar(255) DEFAULT NULL,
  `tecnologias` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proyectos`
--

INSERT INTO `proyectos` (`id`, `nombre`, `descripcion`, `portada`, `tecnologias`, `created_at`) VALUES
(1, 'Landing Page', 'Proyecto hecho con HTML, CSS y JAVASCRIPT donde diseñé una Landing Page con dos banners.', '/img/proyecto1.png', 'HTML, CSS Y JS', '2025-11-20 07:52:06'),
(2, 'Proyecto Bootstrap', 'Una pagina One Page responsiva que debia cumplir con una barra de navegación, una paleta de colores, cards, mapa, reponsive, etc.', '/img/proyecto2.png', 'HTML y CSS', '2025-11-20 08:01:38'),
(3, 'proyecto conexion a php', 'unapagina donde tenes que completar un formulario que este conectado a una base de datos y que los datos carguen en ella', '/img/proyecto3.png', 'HTML Y CSS y php', '2025-11-20 08:06:21'),
(4, 'tarjeta de personaje', 'tarjeta de personaje como primer reto a crear en una pagina', '/img/proyecto4.png', 'HTML Y CSS', '2025-11-20 08:13:57'),
(5, 'pagina de restaurante chinchillo', 'una pagina donde te presenta un restaurante dond ete muestra su informacion y un brebe formulario con conexiion a php', '/img/proyecto5.png', 'HTML Y CSS y php', '2025-11-20 08:21:19'),
(13, 'programa silla', 'nose', '', 'html', '2025-11-27 21:00:54');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
