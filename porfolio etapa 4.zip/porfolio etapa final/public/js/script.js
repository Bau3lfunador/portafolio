const buttons = document.querySelectorAll("button[data-filter]");
const cards = document.querySelectorAll(".card");

buttons.forEach(btn => {
  btn.addEventListener("click", () => {
    const filter = btn.dataset.filter;
    cards.forEach(card => {
      card.style.display =
        filter === "all" || card.dataset.type === filter ? "block" : "none";
    });
  });
});